
import { defuFn } from '/Users/jcu/Desktop/my_skils/migrationNuxt3/my-app/backend/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default /* #__PURE__ */ defuFn(inlineConfig)
