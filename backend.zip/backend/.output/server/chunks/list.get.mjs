import { defineEventHandler } from 'h3';
import { L as List } from './listModel.mjs';
import 'mongoose';

const list_get = defineEventHandler(async (event) => {
  let elements = await List.find({});
  return { elements };
});

export { list_get as default };
//# sourceMappingURL=list.get.mjs.map
