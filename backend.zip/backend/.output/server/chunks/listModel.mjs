import mongoose from 'mongoose';

const listSchema = mongoose.Schema({
  text: String
  // текст, связанный с элементом списка
});
const List = mongoose.model("elements", listSchema);
const List$1 = List;

export { List$1 as L };
//# sourceMappingURL=listModel.mjs.map
