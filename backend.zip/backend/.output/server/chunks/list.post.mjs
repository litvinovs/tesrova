import { defineEventHandler, readBody } from 'h3';
import { L as List } from './listModel.mjs';
import 'mongoose';

const list_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const text = body.text;
  console.log(text);
  let doc = await List.create({ text });
  return { id: doc._id, text };
});

export { list_post as default };
//# sourceMappingURL=list.post.mjs.map
