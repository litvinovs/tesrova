import { defineEventHandler, readBody } from 'h3';
import TelegramBot from 'node-telegram-bot-api';

const token = "6519194051:AAG2kj0L7zwYCl0K3eyfQT2DCtMkoH7Nk6Y";
const bot = new TelegramBot(token, { polling: true });
bot.on("message", (msg) => {
  bot.sendMessage(msg.chat.id, "Hello World!");
});
bot.onText(/\/start/, (msg) => {
  bot.sendMessage(msg.chat.id, "START!");
});
const bot$1 = bot;

const telegram_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  body.text;
  console.log(TEEEST);
  bot$1.sendMessage("\u041F\u0440\u0438\u0432\u0435\u0442! \u042F \u0432\u0430\u0448 \u0431\u043E\u0442.");
});

export { telegram_post as default };
//# sourceMappingURL=telegram.post.mjs.map
