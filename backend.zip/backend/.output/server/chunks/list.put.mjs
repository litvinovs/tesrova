import { defineEventHandler, readBody } from 'h3';
import { L as List } from './listModel.mjs';
import 'mongoose';

const list_put = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const id = body.id;
  const text = body.text;
  await List.updateOne({ _id: id }, { text }).exec();
  return "ok";
});

export { list_put as default };
//# sourceMappingURL=list.put.mjs.map
