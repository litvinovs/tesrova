import { defineEventHandler, readBody } from 'h3';
import { L as List } from './listModel.mjs';
import 'mongoose';

const list_delete = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const id = body.id;
  await List.deleteOne({ _id: id }).exec();
  return "ok";
});

export { list_delete as default };
//# sourceMappingURL=list.delete.mjs.map
